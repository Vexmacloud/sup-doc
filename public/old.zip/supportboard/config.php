<?php

/*
 * ==========================================================
 * INITIAL CONFIGURATION FILE
 * ==========================================================
 *
 * Insert here the information for the database connection and for other core settings.
 *
 */

/* Plugin folder url */
define('SB_URL', 'https://docs.vexmacloud.com/supportboard');

/* The name of the database */
define('SB_DB_NAME', 'supdoc');

/* MySQL database username */
define('SB_DB_USER', 'vexmacloud');

/* MySQL database password */
define('SB_DB_PASSWORD', 'Developer@123');

/* MySQL hostname */
define('SB_DB_HOST', '127.0.0.1');

/* MySQL port (optional) */
define('SB_DB_PORT', '');

/* [extra] */

?>